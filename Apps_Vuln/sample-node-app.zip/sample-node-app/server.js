const express = require("express");
const _ = require("lodash");

const app = express();

app.get("/", (req, res) => {
  res.send("Sample Node.js app for vulnerability scanner testing.");
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Sample app listening on port ${port}`);
});
