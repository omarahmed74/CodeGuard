# Sample Node App (for CodeGuard testing)

A tiny Express app with old, intentionally-vulnerable pinned npm
dependencies — good for testing the vulnerability scan without needing
Snyk's Python/pip venv-install step at all, since Snyk reads
`package-lock.json` statically.

Known vulnerable packages included:
- express 4.16.0
- lodash 4.17.4
- axios 0.18.0
- moment 2.19.3
- jsonwebtoken 8.3.0
- handlebars 4.0.11
