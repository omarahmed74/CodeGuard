// server.js
// Minimal Express app — entry point for the sample vulnerable app.
// Purpose: give M2 (Vuln Scanning) and M1 (SBOM) something real to scan.

const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const usersRouter = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/users', usersRouter);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'sample-vulnerable-app' });
});

app.listen(PORT, () => {
  console.log(`Sample app running at http://localhost:${PORT}`);
});
