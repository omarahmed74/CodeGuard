# Sample Vulnerable App

A tiny Express app used as the input to the SBOM → Vulnerability Scan → AI → Dashboard pipeline.
It intentionally uses older versions of common packages (express, lodash, axios, minimist,
jquery, moment, body-parser) so that SBOM/vuln tools have real CVEs to find.

## Files

- `package.json` — dependency list (the outdated versions live here)
- `server.js` — app entry point, starts the web server
- `routes/users.js` — a small API route that actually uses lodash + moment
- `public/index.html` — front-end page that uses jQuery to call the API

## How to run it locally

1. Install Node.js (v18 or later) if you don't have it.
2. Open a terminal in this folder.
3. Run:
   ```
   npm install
   npm start
   ```
4. Open http://localhost:3000 in your browser.

## Next step: generate the SBOM

Once this runs locally, use Syft to generate the CycloneDX SBOM (see instructions below).
