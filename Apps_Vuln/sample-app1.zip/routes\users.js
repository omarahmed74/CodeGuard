// routes/users.js
// Simple in-memory "users" API — uses lodash + moment so those
// outdated packages actually get exercised (not just listed in package.json).

const express = require('express');
const _ = require('lodash');
const moment = require('moment');

const router = express.Router();

const users = [
  { id: 1, name: 'Sara Ahmed', role: 'analyst', createdAt: '2024-01-10' },
  { id: 2, name: 'Omar Khaled', role: 'admin', createdAt: '2024-03-22' },
  { id: 3, name: 'Laila Hassan', role: 'analyst', createdAt: '2024-05-02' }
];

// GET /api/users  -> list all users, sorted by name
router.get('/', (req, res) => {
  const sorted = _.sortBy(users, 'name');
  const withFormattedDates = sorted.map(u => ({
    ...u,
    createdAt: moment(u.createdAt).format('DD MMM YYYY')
  }));
  res.json(withFormattedDates);
});

// GET /api/users/:id -> get one user
router.get('/:id', (req, res) => {
  const user = _.find(users, { id: Number(req.params.id) });
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

module.exports = router;
